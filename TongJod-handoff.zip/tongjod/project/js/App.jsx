/* App root — routing, theme, state, bottom nav */
const { useState, useEffect, useRef } = React;

function App() {
  const { THEMES, SAMPLE_TX, BUDGETS, computeStatus, MONTH, t } = window;

  const [authed, setAuthed] = useState(false);
  const [lang, setLang] = useState('th');
  const [route, setRoute] = useState('dashboard');
  const [transactions, setTransactions] = useState(SAMPLE_TX.slice());
  const [budgets, setBudgets] = useState({ ...BUDGETS });
  const [formNonce, setFormNonce] = useState(0);
  const [toast, setToast] = useState(null);
  const phoneRef = useRef(null);

  // ----- derive theme -----
  const totalExpense = transactions.filter((x) => x.type === 'expense').reduce((s, x) => s + x.amount, 0);
  const budgetTotal = Object.values(budgets).reduce((s, v) => s + v, 0);
  const hasBudget = budgetTotal > 0;
  const expectedPct = Math.round((MONTH.today / MONTH.daysInMonth) * 100);
  const actualPct = hasBudget ? Math.round((totalExpense / budgetTotal) * 100) : 0;
  const statusKey = computeStatus(actualPct, expectedPct, hasBudget);
  const theme = THEMES[statusKey];
  const appliedTheme = authed ? theme : THEMES.default;

  // ----- apply theme vars -----
  useEffect(() => {
    const el = phoneRef.current;
    if (!el) return;
    const tm = appliedTheme;
    el.dataset.theme = tm.key;
    el.style.setProperty('--accent', tm.accent);
    el.style.setProperty('--accent-light', tm.accentLight);
    el.style.setProperty('--bar', tm.bar);
    el.style.setProperty('--pill-bg', tm.pillBg);
    el.style.setProperty('--pill-text', tm.pillText);
    el.style.setProperty('--card-tint', tm.cardTint);
    el.style.setProperty('--focus-ring', tm.focusRing);
    const bg = el.querySelector('.phone-bg');
    if (bg) bg.style.background = tm.gradient;
    document.documentElement.style.setProperty('--app-gradient', tm.gradient);
  }, [appliedTheme.key]);

  const lastTx = [...transactions].filter((x) => x.userAdded).slice(-1)[0]
    || transactions[transactions.length - 1];

  const handleSave = (draft) => {
    const tx = {
      id: 'u' + Date.now(), type: draft.type, day: draft.day, cat: draft.cat,
      amount: Number(draft.amount), note: draft.note, userAdded: true,
    };
    setTransactions((list) => [...list, tx]);
    setFormNonce((n) => n + 1);
    setRoute('dashboard');
    setToast(t('saved', lang));
    setTimeout(() => setToast(null), 1800);
  };

  const setBudget = (id, value) => setBudgets((b) => ({ ...b, [id]: value }));

  return (
    <div className="stage">
      <div className="phone" ref={phoneRef} data-theme={appliedTheme.key}>
        <div className="phone-bg"></div>

        <div className="screen">
          {!authed && <window.Login lang={lang} onSignIn={() => setAuthed(true)} />}

          {authed && route === 'dashboard' && (
            <window.Dashboard lang={lang} setLang={setLang} transactions={transactions}
              budgets={budgets} theme={theme} onMonth={() => {}} />
          )}
          {authed && route === 'form' && (
            <window.Form key={formNonce} lang={lang} setLang={setLang} onSave={handleSave} lastTx={lastTx} />
          )}
          {authed && route === 'budget' && (
            <window.Budget lang={lang} setLang={setLang} budgets={budgets} setBudget={setBudget} theme={theme} />
          )}

          {authed && <BottomNav route={route} setRoute={(r) => { if (r === 'form') setFormNonce((n) => n + 1); setRoute(r); }} lang={lang} theme={theme} />}
        </div>

        {toast && <Toast text={toast} />}
      </div>
    </div>
  );
}

function BottomNav({ route, setRoute, lang, theme }) {
  const Icon = window.Icon;
  const tabs = [
    { id: 'dashboard', icon: 'LayoutDashboard', label: window.t('navHome', lang) },
    { id: 'form', icon: 'Plus', label: window.t('navAdd', lang), primary: true },
    { id: 'budget', icon: 'Wallet', label: window.t('navBudget', lang) },
  ];
  return (
    <div style={{
      height: 64, flexShrink: 0, background: 'var(--surface)', borderTop: '1px solid var(--border)',
      boxShadow: 'var(--sh-nav)', display: 'flex', alignItems: 'stretch',
      paddingBottom: 'env(safe-area-inset-bottom)',
    }}>
      {tabs.map((tab) => {
        const active = route === tab.id;
        if (tab.primary) {
          return (
            <div key={tab.id} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <button onClick={() => setRoute(tab.id)} aria-label={tab.label} style={{
                width: 52, height: 52, borderRadius: 18, border: 'none', cursor: 'pointer',
                background: `linear-gradient(135deg, ${theme.accentLight}, ${theme.accent})`,
                boxShadow: `0 6px 16px ${theme.cardTint}, var(--sh-button)`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transform: active ? 'translateY(-2px)' : 'none', transition: 'transform 160ms ease-out',
              }}
                onMouseDown={(e) => (e.currentTarget.style.transform = 'scale(0.94)')}
                onMouseUp={(e) => (e.currentTarget.style.transform = active ? 'translateY(-2px)' : 'none')}
                onMouseLeave={(e) => (e.currentTarget.style.transform = active ? 'translateY(-2px)' : 'none')}>
                <Icon name="Plus" size={26} color="#fff" strokeWidth={2.4} />
              </button>
            </div>
          );
        }
        return (
          <button key={tab.id} onClick={() => setRoute(tab.id)} style={{
            flex: 1, border: 'none', background: 'transparent', cursor: 'pointer', position: 'relative',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
          }}>
            <Icon name={tab.icon} size={22} color={active ? theme.accent : 'var(--text-muted)'} strokeWidth={active ? 2.3 : 2} />
            {active
              ? <span className="label thai" style={{ color: theme.accent, fontWeight: 600, whiteSpace: 'nowrap' }}>{tab.label}</span>
              : <span style={{ width: 4, height: 4, borderRadius: 999, background: 'transparent' }}></span>}
            {active && <span style={{ position: 'absolute', top: 9, width: 16, height: 3, borderRadius: 999, background: theme.accent }}></span>}
          </button>
        );
      })}
    </div>
  );
}

function Toast({ text }) {
  return (
    <div style={{
      position: 'absolute', bottom: 84, left: '50%', transform: 'translateX(-50%)', zIndex: 60,
      background: 'var(--text-primary)', color: '#fff', padding: '12px 20px', borderRadius: 999,
      fontFamily: 'var(--body)', fontWeight: 600, fontSize: 14, display: 'flex', alignItems: 'center', gap: 8,
      boxShadow: '0 8px 24px rgba(28,25,23,0.3)', animation: 'cardIn 280ms ease-out both', whiteSpace: 'nowrap',
    }}>
      <window.Icon name="CircleCheck" size={18} color="#fff" />
      <span className="thai">{text}</span>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
