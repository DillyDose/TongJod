/* Budget editor */
function Budget({ lang, setLang, budgets, setBudget, theme }) {
  const Icon = window.Icon;
  const { t, fmt, EXPENSE_CATEGORIES, INCOME_CATEGORIES } = window;

  const [expCats, setExpCats] = React.useState(() => EXPENSE_CATEGORIES.slice(0, 6).map((c) => c.id));
  const [incCats, setIncCats] = React.useState(() => INCOME_CATEGORIES.slice(0, 3).map((c) => c.id));
  const [sheet, setSheet] = React.useState(null); // 'expense' | 'income' | null

  const total = expCats.reduce((s, id) => s + (budgets[id] || 0), 0);

  const addCat = (kind, name) => {
    const id = 'custom_' + Date.now();
    const cat = { id, icon: kind === 'income' ? 'Coins' : 'Tag', th: name, en: name, usage: 0 };
    window.EXPENSE_CATEGORIES.push(cat); // register so catById can resolve
    if (kind === 'income') setIncCats((l) => [...l, id]);
    else { setExpCats((l) => [...l, id]); setBudget(id, 0); }
    setSheet(null);
  };

  return (
    <React.Fragment>
      <Header lang={lang} setLang={setLang}>
        <span className="h2 thai" style={{ color: 'var(--text-primary)', whiteSpace: 'nowrap' }}>{t('budgetTitle', lang)}</span>
      </Header>

      <div className="scroll" style={{ flex: 1, padding: '4px 16px 96px' }}>
        {/* total card */}
        <div className="card anim-card" style={{ background: 'rgba(255,255,255,0.82)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div className="label thai" style={{ color: 'var(--text-secondary)', marginBottom: 6 }}>{t('totalBudget', lang)}</div>
            <div className="caption thai" style={{ color: 'var(--text-muted)' }}>{t('monthlyBudgetNote', lang)}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 5 }}>
            <span className="display" style={{ fontSize: 32, color: theme.accent }}>{fmt(total)}</span>
            <span className="caption thai" style={{ color: 'var(--text-secondary)' }}>{t('baht', lang)}</span>
          </div>
        </div>

        {/* Expense budgets */}
        <SectionLabel icon="TrendingDown" color="#DC2626" text={t('expense', lang)} />
        <div className="card anim-card" style={{ padding: 4, animationDelay: '40ms' }}>
          {expCats.map((id, i) => {
            const c = window.catById(id);
            return (
              <BudgetRow key={id} cat={c} lang={lang} theme={theme} last={i === expCats.length - 1}
                value={budgets[id]} onChange={(v) => setBudget(id, v)}
                onDelete={() => { setExpCats((l) => l.filter((x) => x !== id)); }} />
            );
          })}
        </div>
        <AddBtn lang={lang} onClick={() => setSheet('expense')} />

        {/* Income categories */}
        <SectionLabel icon="TrendingUp" color="#059669" text={t('income', lang)} />
        <div className="card anim-card" style={{ padding: 4, animationDelay: '80ms' }}>
          {incCats.map((id, i) => {
            const c = window.catById(id);
            return (
              <div key={id} style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '14px 14px', borderBottom: i < incCats.length - 1 ? '1px solid var(--border)' : 'none',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                  <span style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--surface-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <window.Icon name={c ? c.icon : 'Coins'} size={16} color="var(--text-secondary)" />
                  </span>
                  <span className="body-med thai" style={{ whiteSpace: 'nowrap' }}>{c ? c[lang] : id}</span>
                </div>
                <button onClick={() => setIncCats((l) => l.filter((x) => x !== id))} style={delBtn} aria-label="delete">
                  <window.Icon name="Trash2" size={16} color="var(--text-muted)" />
                </button>
              </div>
            );
          })}
        </div>
        <AddBtn lang={lang} onClick={() => setSheet('income')} />
      </div>

      {sheet && <AddSheet kind={sheet} lang={lang} onClose={() => setSheet(null)} onAdd={(name) => addCat(sheet, name)} />}
    </React.Fragment>
  );
}

function BudgetRow({ cat, lang, value, onChange, onDelete, last, theme }) {
  const Icon = window.Icon;
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '12px 14px', borderBottom: last ? 'none' : '1px solid var(--border)',
    }}>
      <span style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--surface-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon name={cat ? cat.icon : 'Tag'} size={16} color="var(--text-secondary)" />
      </span>
      <span className="body-med thai" style={{ flex: 1 }}>{cat ? cat[lang] : ''}</span>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, padding: '4px 8px', borderRadius: 8, background: focus ? 'var(--card-tint)' : 'transparent', transition: 'background 150ms' }}>
        <input
          inputMode="numeric"
          value={value ? value.toLocaleString('en-US') : ''}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          onChange={(e) => { const n = Number(e.target.value.replace(/[^0-9]/g, '')); onChange(n); }}
          placeholder={window.t('notSet', lang)}
          className="thai"
          style={{
            width: value ? Math.max(48, String(value.toLocaleString('en-US')).length * 11 + 10) : 76,
            border: 'none', outline: 'none', background: 'transparent', textAlign: 'right',
            fontFamily: 'var(--display)', fontWeight: 600, fontSize: 16,
            color: value ? theme.accent : 'var(--text-muted)',
          }}
        />
        <span className="caption thai" style={{ color: 'var(--text-muted)' }}>{window.t('baht', lang)}</span>
      </div>
      <button onClick={onDelete} style={delBtn} aria-label="delete">
        <Icon name="Trash2" size={16} color="var(--text-muted)" />
      </button>
    </div>
  );
}

const delBtn = {
  width: 32, height: 32, borderRadius: 8, border: 'none', background: 'transparent',
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
};

function SectionLabel({ icon, color, text }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '22px 4px 10px' }}>
      <window.Icon name={icon} size={16} color={color} />
      <span className="label thai" style={{ color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.06em', whiteSpace: 'nowrap' }}>{text}</span>
    </div>
  );
}

function AddBtn({ lang, onClick }) {
  return (
    <button onClick={onClick} className="thai" style={{
      width: '100%', marginTop: 10, padding: '13px', borderRadius: 12, cursor: 'pointer',
      background: 'transparent', border: '1.5px dashed var(--border)', color: 'var(--text-secondary)',
      fontFamily: 'var(--body)', fontWeight: 500, fontSize: 14,
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      transition: 'background 150ms',
    }}
      onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.4)')}
      onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
      <window.Icon name="Plus" size={16} /> {window.t('addCategory', lang)}
    </button>
  );
}

function AddSheet({ kind, lang, onClose, onAdd }) {
  const [name, setName] = React.useState('');
  const submit = () => { if (name.trim()) onAdd(name.trim()); };
  return (
    <div onClick={onClose} style={{
      position: 'absolute', inset: 0, zIndex: 50, background: 'rgba(28,25,23,0.35)',
      display: 'flex', alignItems: 'flex-end', animation: 'fadeIn 200ms ease-out',
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        width: '100%', background: 'var(--surface)', borderRadius: '24px 24px 0 0',
        padding: '20px 20px calc(20px + env(safe-area-inset-bottom))', animation: 'sheetUp 280ms ease-out',
      }}>
        <div style={{ width: 40, height: 4, borderRadius: 999, background: 'var(--border)', margin: '0 auto 18px' }}></div>
        <div className="h2 thai" style={{ marginBottom: 16 }}>{window.t('newCategory', lang)}</div>
        <input className="input thai" autoFocus value={name} onChange={(e) => setName(e.target.value)}
          placeholder={window.t('categoryName', lang)} onKeyDown={(e) => e.key === 'Enter' && submit()} />
        <button className="btn-primary" onClick={submit} disabled={!name.trim()} style={{ width: '100%', marginTop: 16 }}>
          <span className="thai">{window.t('save', lang)}</span>
        </button>
      </div>
    </div>
  );
}

window.Budget = Budget;
