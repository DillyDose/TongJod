/* Dashboard */
function Dashboard({ lang, setLang, transactions, budgets, theme, onMonth }) {
  const Icon = window.Icon;
  const { t, fmt, MONTH, EXPENSE_CATEGORIES, catById } = window;

  const income = transactions.filter((x) => x.type === 'income');
  const expense = transactions.filter((x) => x.type === 'expense');
  const totalIncome = income.reduce((s, x) => s + x.amount, 0);
  const totalExpense = expense.reduce((s, x) => s + x.amount, 0);
  const budgetTotal = Object.values(budgets).reduce((s, v) => s + v, 0);
  const hasBudget = budgetTotal > 0;

  const days = MONTH.today;
  const expectedPct = Math.round((days / MONTH.daysInMonth) * 100);
  const actualPct = hasBudget ? Math.round((totalExpense / budgetTotal) * 100) : 0;

  const avgIncome = totalIncome / days;
  const avgExpense = totalExpense / days;

  // daily expense series
  const daily = [];
  for (let d = 1; d <= days; d++) {
    daily.push(expense.filter((x) => x.day === d).reduce((s, x) => s + x.amount, 0));
  }
  const maxDaily = Math.max(...daily, 1);

  // top categories
  const byCat = {};
  expense.forEach((x) => { byCat[x.cat] = (byCat[x.cat] || 0) + x.amount; });
  const top = Object.entries(byCat).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const maxCat = top.length ? top[0][1] : 1;

  const statusMsg = { excellent: 'statusExcellent', onTrack: 'statusOnTrack', over: 'statusOver', default: 'statusDefault' }[theme.key];
  const statusLabel = {
    excellent: lang === 'th' ? 'ดีเยี่ยม' : 'Excellent',
    onTrack: lang === 'th' ? 'กำลังดี' : 'On track',
    over: lang === 'th' ? 'เกินงบ' : 'Over budget',
    default: lang === 'th' ? 'ยังไม่ตั้งงบ' : 'No budget',
  }[theme.key];

  return (
    <React.Fragment>
      <Header lang={lang} setLang={setLang}>
        <button className="month-sel" onClick={onMonth} style={{
          display: 'flex', alignItems: 'center', gap: 6, background: 'rgba(255,255,255,0.55)',
          border: '1px solid rgba(255,255,255,0.6)', borderRadius: 'var(--r-full)', padding: '7px 14px',
          cursor: 'pointer', fontFamily: 'var(--display)', fontWeight: 600, fontSize: 15, color: 'var(--text-primary)',
        }}>
          <span className="thai" style={{ whiteSpace: 'nowrap' }}>{MONTH[lang]} {MONTH.year + 543 - (lang === 'en' ? 543 : 0)}</span>
          <Icon name="ChevronDown" size={16} />
        </button>
      </Header>

      <div className="scroll" style={{ flex: 1, padding: '4px 16px 96px' }}>
        {/* Status + progress */}
        <div className="card anim-card" style={{ background: theme.cardTint ? 'rgba(255,255,255,0.82)' : '#fff', backdropFilter: 'blur(8px)', textAlign: 'center' }}>
          <div className="pill" style={{ background: theme.pillBg, color: theme.pillText, margin: '0 auto', whiteSpace: 'nowrap' }}>
            <span style={{ width: 7, height: 7, borderRadius: 999, background: theme.accent, display: 'inline-block' }}></span>
            {statusLabel}
          </div>
          <div key={statusMsg} className="body-med thai anim-fade" style={{ marginTop: 12, fontSize: 16, color: 'var(--text-primary)' }}>
            {t(statusMsg, lang)}
          </div>

          {hasBudget && (
            <div style={{ marginTop: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span className="caption thai" style={{ color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{t('expected', lang, { n: expectedPct })}</span>
                <span className="caption thai" style={{ color: theme.accent, fontWeight: 600, whiteSpace: 'nowrap' }}>{t('actual', lang, { n: actualPct })}</span>
              </div>
              <div style={{ position: 'relative', height: 12, background: 'var(--surface-secondary)', borderRadius: 999 }}>
                <div style={{
                  position: 'absolute', left: 0, top: 0, bottom: 0,
                  width: Math.min(actualPct, 100) + '%',
                  background: `linear-gradient(90deg, ${theme.accentLight}, ${theme.accent})`,
                  borderRadius: 999, transition: 'width 600ms ease-out',
                }}></div>
                <div style={{
                  position: 'absolute', top: -3, bottom: -3, left: Math.min(expectedPct, 100) + '%',
                  width: 3, background: '#fff', borderRadius: 2, transform: 'translateX(-50%)',
                  boxShadow: '0 1px 4px rgba(28,25,23,0.35)',
                }}></div>
              </div>
            </div>
          )}
        </div>

        {/* Summary cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 12 }}>
          <SummaryCard tint="rgba(16,185,129,0.08)" iconBg="rgba(16,185,129,0.14)" iconColor="#059669"
            icon="TrendingUp" label={t('income', lang)} value={totalIncome} avg={avgIncome} lang={lang} delay={40} />
          <SummaryCard tint="rgba(239,68,68,0.08)" iconBg="rgba(239,68,68,0.14)" iconColor="#DC2626"
            icon="TrendingDown" label={t('expense', lang)} value={totalExpense} avg={avgExpense} lang={lang} delay={90} />
        </div>

        {/* Timeline */}
        <div className="card anim-card" style={{ marginTop: 12, animationDelay: '120ms' }}>
          <div className="h2 thai" style={{ marginBottom: 16 }}>{t('dailyExpense', lang)}</div>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: daily.length > 16 ? 3 : 6, height: 120 }}>
            {daily.map((v, i) => (
              <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, height: '100%', justifyContent: 'flex-end' }}>
                <div style={{
                  width: '100%', maxWidth: 22,
                  height: Math.max((v / maxDaily) * 96, v > 0 ? 6 : 2) + 'px',
                  background: v > 0 ? `linear-gradient(180deg, ${theme.accentLight}, ${theme.accent})` : 'var(--surface-secondary)',
                  borderRadius: 6, transformOrigin: 'bottom',
                  animation: `growBar 500ms ease-out ${150 + i * 28}ms both`,
                }} title={fmt(v)}></div>
                <span className="label" style={{ color: 'var(--text-muted)', fontSize: 10 }}>{i + 1}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Top categories */}
        <div className="card anim-card" style={{ marginTop: 12, animationDelay: '160ms' }}>
          <div className="h2 thai" style={{ marginBottom: 16 }}>{t('topCategories', lang)}</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {top.map(([cid, amt], i) => {
              const c = catById(cid);
              return (
                <div key={cid}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 9, minWidth: 0 }}>
                      <span style={{ width: 22, height: 22, borderRadius: 7, background: theme.cardTint, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <Icon name={c ? c.icon : 'Shapes'} size={13} color={theme.accent} />
                      </span>
                      <span className="body-med thai" style={{ fontSize: 14, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c ? c[lang] : cid}</span>
                    </div>
                    <span className="body-med" style={{ fontSize: 14, color: 'var(--text-primary)', flexShrink: 0, paddingLeft: 8 }}>{fmt(amt)}</span>
                  </div>
                  <div style={{ height: 8, background: 'var(--surface-secondary)', borderRadius: 999 }}>
                    <div style={{
                      width: (amt / maxCat) * 100 + '%', height: '100%',
                      background: `linear-gradient(90deg, ${theme.accent}, ${theme.accentLight})`,
                      borderRadius: 999, animation: `growBarX 600ms ease-out ${200 + i * 60}ms both`,
                    }}></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

function SummaryCard({ tint, iconBg, iconColor, icon, label, value, avg, lang, delay }) {
  const Icon = window.Icon;
  return (
    <div className="card anim-card" style={{ background: tint, animationDelay: delay + 'ms', padding: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <span style={{ width: 28, height: 28, borderRadius: 9, background: iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={icon} size={16} color={iconColor} />
        </span>
        <span className="label thai" style={{ color: 'var(--text-secondary)', fontSize: 13, whiteSpace: 'nowrap' }}>{label}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 5 }}>
        <span className="display" style={{ fontSize: 28 }}>{window.fmt(value)}</span>
        <span className="caption thai" style={{ color: 'var(--text-secondary)' }}>{window.t('baht', lang)}</span>
      </div>
      <div className="caption thai" style={{ marginTop: 4, color: 'var(--text-muted)' }}>
        {window.t('avgPerDay', lang, { n: window.fmt(avg) })}
      </div>
    </div>
  );
}

function Header({ lang, setLang, children }) {
  const Icon = window.Icon;
  return (
    <div style={{ height: 56, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px' }}>
      <div>{children}</div>
      <LangToggle lang={lang} setLang={setLang} />
    </div>
  );
}

function LangToggle({ lang, setLang }) {
  return (
    <button onClick={() => setLang(lang === 'th' ? 'en' : 'th')} style={{
      display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.55)',
      border: '1px solid rgba(255,255,255,0.6)', borderRadius: 999, padding: 3, cursor: 'pointer', gap: 2,
    }}>
      {['th', 'en'].map((l) => (
        <span key={l} style={{
          padding: '4px 10px', borderRadius: 999, fontFamily: 'var(--body)', fontWeight: 600, fontSize: 12,
          background: lang === l ? 'var(--accent)' : 'transparent',
          color: lang === l ? '#fff' : 'var(--text-secondary)',
          transition: 'all 180ms ease-out', textTransform: 'uppercase',
        }}>{l}</span>
      ))}
    </button>
  );
}

window.Dashboard = Dashboard;
window.Header = Header;
window.LangToggle = LangToggle;
