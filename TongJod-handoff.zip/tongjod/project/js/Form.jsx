/* Add-transaction form — 6 steps */
function Form({ lang, setLang, onSave, lastTx }) {
  const Icon = window.Icon;
  const { t, fmt, EXPENSE_CATEGORIES, INCOME_CATEGORIES, MONTH, catById } = window;
  const TOTAL = 6;

  const [step, setStep] = React.useState(1);
  const [dir, setDir] = React.useState('fwd');
  const [draft, setDraft] = React.useState({
    type: null, amount: '', cat: null, note: '', day: MONTH.today,
  });

  const go = (n) => { setDir(n > step ? 'fwd' : 'back'); setStep(n); };
  const next = () => go(Math.min(step + 1, TOTAL));
  const back = () => go(Math.max(step - 1, 1));
  const set = (patch) => setDraft((d) => ({ ...d, ...patch }));

  const editLast = () => {
    if (!lastTx) return;
    setDraft({ type: lastTx.type, amount: String(lastTx.amount), cat: lastTx.cat, note: lastTx.note || '', day: lastTx.day });
    setDir('fwd'); setStep(2);
  };

  const cats = (draft.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES)
    .slice().sort((a, b) => b.usage - a.usage);
  const animClass = dir === 'fwd' ? 'anim-in-right' : 'anim-in-left';

  return (
    <React.Fragment>
      {/* header */}
      <div style={{ height: 56, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px' }}>
        <div style={{ width: 40 }}>
          {step > 1 && (
            <button onClick={back} aria-label="back" style={iconBtn}>
              <Icon name="ArrowLeft" size={20} color="var(--text-primary)" />
            </button>
          )}
        </div>
        <Dots step={step} total={TOTAL} />
        <div style={{ width: 40 }}></div>
      </div>

      <div className="scroll" style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '0 20px 24px' }}>
        <div key={step} className={animClass} style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', paddingTop: 8 }}>

          {step === 1 && (
            <StepWrap q={t('formType', lang)}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 8 }}>
                <TypeCard active={draft.type === 'income'} onClick={() => { set({ type: 'income', cat: null }); setTimeout(next, 160); }}
                  icon="TrendingUp" color="#059669" bg="rgba(16,185,129,0.10)" label={t('income', lang)} />
                <TypeCard active={draft.type === 'expense'} onClick={() => { set({ type: 'expense', cat: null }); setTimeout(next, 160); }}
                  icon="TrendingDown" color="#DC2626" bg="rgba(239,68,68,0.10)" label={t('expense', lang)} />
              </div>
              {lastTx && (
                <button onClick={editLast} className="thai" style={{
                  marginTop: 22, background: 'none', border: 'none', cursor: 'pointer',
                  color: 'var(--text-secondary)', fontFamily: 'var(--body)', fontSize: 14, fontWeight: 500,
                  alignSelf: 'center', display: 'inline-flex', gap: 4, alignItems: 'center', whiteSpace: 'nowrap',
                }}>
                  {t('editLast', lang)} <Icon name="ArrowRight" size={15} />
                </button>
              )}
            </StepWrap>
          )}

          {step === 2 && (
            <StepWrap q={t('formAmount', lang)}>
              <AmountPad value={draft.amount} onChange={(v) => set({ amount: v })} lang={lang} accentType={draft.type} />
              <button className="btn-primary" disabled={!draft.amount || Number(draft.amount) <= 0}
                onClick={next} style={{ width: '100%', marginTop: 18 }}>
                <span className="thai">{t('continue', lang)}</span>
              </button>
            </StepWrap>
          )}

          {step === 3 && (
            <StepWrap q={t('formCategory', lang)}>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, justifyContent: 'center', marginTop: 6 }}>
                {cats.map((c) => (
                  <Chip key={c.id} selected={draft.cat === c.id} label={c[lang]} icon={c.icon}
                    onClick={() => { set({ cat: c.id }); setTimeout(next, 200); }} />
                ))}
              </div>
            </StepWrap>
          )}

          {step === 4 && (
            <StepWrap q={t('formNote', lang)}>
              <input className="input thai" autoFocus value={draft.note}
                onChange={(e) => set({ note: e.target.value })}
                placeholder={t('notePlaceholder', lang)}
                onKeyDown={(e) => e.key === 'Enter' && next()} />
              <button className="btn-primary" onClick={next} style={{ width: '100%', marginTop: 16 }}>
                <span className="thai">{t('continue', lang)}</span>
              </button>
              <button className="thai" onClick={() => { set({ note: '' }); next(); }} style={{
                marginTop: 14, background: 'none', border: 'none', cursor: 'pointer', alignSelf: 'center',
                color: 'var(--text-secondary)', fontFamily: 'var(--body)', fontSize: 14, fontWeight: 500,
                display: 'inline-flex', gap: 4, alignItems: 'center', whiteSpace: 'nowrap',
              }}>
                {t('skip', lang)} <Icon name="ArrowRight" size={15} />
              </button>
            </StepWrap>
          )}

          {step === 5 && (
            <StepWrap q={t('formDate', lang)}>
              <DatePick day={draft.day} onChange={(d) => set({ day: d })} lang={lang} />
              <button className="btn-primary" onClick={next} style={{ width: '100%', marginTop: 18 }}>
                <span className="thai">{t('continue', lang)}</span>
              </button>
            </StepWrap>
          )}

          {step === 6 && (
            <Confirm draft={draft} lang={lang} onSave={() => onSave(draft)} onEdit={() => go(1)} />
          )}
        </div>
      </div>
    </React.Fragment>
  );
}

const iconBtn = {
  width: 40, height: 40, borderRadius: 999, border: 'none', background: 'rgba(255,255,255,0.5)',
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
};

function StepWrap({ q, children }) {
  return (
    <div>
      <div className="h1 thai" style={{ textAlign: 'center', marginBottom: 24 }}>{q}</div>
      {children}
    </div>
  );
}

function Dots({ step, total }) {
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
      {Array.from({ length: total }).map((_, i) => {
        const active = i + 1 === step;
        const done = i + 1 < step;
        return <span key={i} style={{
          width: active ? 24 : 8, height: 8, borderRadius: 999,
          background: active || done ? 'var(--accent)' : 'var(--border)',
          opacity: done ? 0.45 : 1, transition: 'all 280ms ease-out',
        }}></span>;
      })}
    </div>
  );
}

function TypeCard({ active, onClick, icon, color, bg, label }) {
  const Icon = window.Icon;
  return (
    <button onClick={onClick} style={{
      width: '100%', minHeight: 84, cursor: 'pointer', textAlign: 'left',
      background: active ? bg : 'var(--surface)',
      border: `1.5px solid ${active ? color : 'var(--border)'}`,
      borderRadius: 16, padding: '0 20px', boxShadow: 'var(--sh-card)',
      display: 'flex', alignItems: 'center', gap: 16,
      transition: 'transform 120ms ease-out, border-color 150ms, background 150ms',
    }}
      onMouseDown={(e) => (e.currentTarget.style.transform = 'scale(0.98)')}
      onMouseUp={(e) => (e.currentTarget.style.transform = 'none')}
      onMouseLeave={(e) => (e.currentTarget.style.transform = 'none')}>
      <span style={{ width: 48, height: 48, borderRadius: 14, background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon name={icon} size={24} color={color} />
      </span>
      <span className="h2 thai" style={{ fontSize: 19, whiteSpace: 'nowrap' }}>{label}</span>
    </button>
  );
}

function Chip({ selected, label, icon, onClick }) {
  const Icon = window.Icon;
  return (
    <button onClick={onClick} className="thai" style={{
      display: 'inline-flex', alignItems: 'center', gap: 7, cursor: 'pointer',
      background: selected ? 'var(--accent)' : 'var(--surface-secondary)',
      border: '1.5px solid transparent', borderRadius: 24, padding: '10px 16px',
      fontFamily: 'var(--body)', fontWeight: 500, fontSize: 14,
      color: selected ? '#fff' : 'var(--text-primary)',
      transform: selected ? 'scale(1.04)' : 'scale(1)',
      transition: 'transform 180ms ease-out, background 150ms', whiteSpace: 'nowrap',
    }}>
      <Icon name={icon} size={15} color={selected ? '#fff' : 'var(--text-secondary)'} />
      {label}
    </button>
  );
}

function AmountPad({ value, onChange, lang, accentType }) {
  const display = value === '' ? '0' : Number(value).toLocaleString('en-US');
  const press = (k) => {
    if (k === 'del') { onChange(value.slice(0, -1)); return; }
    let v = value;
    if (k === '.') { if (v.includes('.') || v === '') return; v += '.'; }
    else {
      const dec = v.split('.')[1];
      if (dec && dec.length >= 2) return;
      if (v === '0') v = k; else v += k;
    }
    if (v.replace('.', '').length > 9) return;
    onChange(v);
  };
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0', 'del'];
  const Icon = window.Icon;
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 8, padding: '4px 0 18px' }}>
        <span className="display" style={{ fontSize: 52, color: value === '' ? '#A8A29E' : '#1C1917' }}>{display}</span>
        <span className="h2 thai" style={{ color: 'var(--text-secondary)' }}>{window.t('baht', lang)}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
        {keys.map((k) => (
          <button key={k} onClick={() => press(k)} style={{
            height: 56, borderRadius: 14, border: 'none', cursor: 'pointer',
            background: k === 'del' ? 'transparent' : 'var(--surface)',
            boxShadow: k === 'del' ? 'none' : 'var(--sh-card)',
            fontFamily: 'var(--display)', fontWeight: 600, fontSize: 22, color: 'var(--text-primary)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'transform 120ms ease-out',
          }}
            onMouseDown={(e) => (e.currentTarget.style.transform = 'scale(0.94)')}
            onMouseUp={(e) => (e.currentTarget.style.transform = 'none')}
            onMouseLeave={(e) => (e.currentTarget.style.transform = 'none')}>
            {k === 'del' ? <Icon name="Delete" size={22} color="var(--text-secondary)" /> : k}
          </button>
        ))}
      </div>
    </div>
  );
}

function DatePick({ day, onChange, lang }) {
  const { MONTH } = window;
  const isToday = day === MONTH.today;
  // build a mini week strip around the chosen day
  const span = [];
  for (let d = Math.max(1, MONTH.today - 4); d <= MONTH.today; d++) span.push(d);
  const dowTh = ['อา', 'จ', 'อ', 'พ', 'พฤ', 'ศ', 'ส'];
  const dowEn = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  // June 1 2026 is a Monday (index 1)
  const dow = (d) => (1 + (d - 1)) % 7;
  return (
    <div>
      <div style={{ display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
        {span.map((d) => {
          const sel = d === day;
          return (
            <button key={d} onClick={() => onChange(d)} style={{
              width: 52, padding: '10px 0', borderRadius: 16, cursor: 'pointer',
              background: sel ? 'var(--accent)' : 'var(--surface)',
              border: `1.5px solid ${sel ? 'var(--accent)' : 'var(--border)'}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              boxShadow: sel ? 'var(--sh-button)' : 'none', transition: 'all 160ms ease-out',
            }}>
              <span className="label thai" style={{ color: sel ? 'rgba(255,255,255,0.85)' : 'var(--text-muted)' }}>
                {(lang === 'th' ? dowTh : dowEn)[dow(d)]}
              </span>
              <span className="h2" style={{ fontSize: 18, color: sel ? '#fff' : 'var(--text-primary)' }}>{d}</span>
            </button>
          );
        })}
      </div>
      <button onClick={() => onChange(MONTH.today)} className="thai" style={{
        marginTop: 16, width: '100%', padding: '12px', borderRadius: 12, cursor: 'pointer',
        background: isToday ? 'var(--card-tint)' : 'transparent',
        border: '1px dashed var(--border)', color: 'var(--text-secondary)',
        fontFamily: 'var(--body)', fontWeight: 500, fontSize: 14,
      }}>
        {window.t('today', lang)} · {MONTH[lang]} {MONTH.today}
      </button>
    </div>
  );
}

function Confirm({ draft, lang, onSave, onEdit }) {
  const { t, fmt, catById, MONTH } = window;
  const c = catById(draft.cat);
  const rows = [
    { k: t('fType', lang), v: t(draft.type === 'income' ? 'income' : 'expense', lang), color: draft.type === 'income' ? '#059669' : '#DC2626' },
    { k: t('fAmount', lang), v: fmt(Number(draft.amount)) + ' ' + t('baht', lang) },
    { k: t('fCategory', lang), v: c ? c[lang] : '—' },
    { k: t('fNote', lang), v: draft.note || t('noNote', lang) },
    { k: t('fDate', lang), v: `${MONTH[lang]} ${draft.day}` },
  ];
  return (
    <div>
      <div className="h2 thai" style={{ textAlign: 'center', marginBottom: 20 }}>{t('formConfirm', lang)}</div>
      <div className="card" style={{ padding: 4 }}>
        {rows.map((r, i) => (
          <div key={i} style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '14px 16px', borderBottom: i < rows.length - 1 ? '1px solid var(--border)' : 'none',
          }}>
            <span className="caption thai" style={{ color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{r.k}</span>
            <span className="body-med thai" style={{ color: r.color || '#1C1917', fontWeight: 600, whiteSpace: 'nowrap', textAlign: 'right' }}>{r.v}</span>
          </div>
        ))}
      </div>
      <button className="btn-primary" onClick={onSave} style={{ width: '100%', marginTop: 20 }}>
        <window.Icon name="Check" size={18} color="#fff" />
        <span className="thai">{t('save', lang)}</span>
      </button>
      <button onClick={onEdit} className="thai" style={{
        marginTop: 12, width: '100%', background: 'none', border: 'none', cursor: 'pointer',
        color: 'var(--text-secondary)', fontFamily: 'var(--body)', fontSize: 14, fontWeight: 500,
      }}>
        {t('edit', lang)}
      </button>
    </div>
  );
}

window.Form = Form;
