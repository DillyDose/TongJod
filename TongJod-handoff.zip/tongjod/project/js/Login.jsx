/* Login screen */
function Login({ lang, onSignIn }) {
  const Icon = window.Icon;
  return (
    <div className="screen anim-fade" style={{ justifyContent: 'center', alignItems: 'center', padding: '0 28px' }}>
      <div style={{ position: 'absolute', top: '20%', textAlign: 'center', left: 0, right: 0, padding: '0 28px' }}>
        <div style={{
          width: 76, height: 76, margin: '0 auto 22px',
          borderRadius: 24, background: 'rgba(255,255,255,0.7)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 24px rgba(28,25,23,0.12)', backdropFilter: 'blur(4px)',
        }}>
          <Icon name="NotebookPen" size={38} color="var(--text-primary)" strokeWidth={1.8} />
        </div>
        <div className="display thai" style={{ fontSize: 44 }}>ต้องจด</div>
        <div className="body-med" style={{ marginTop: 4, letterSpacing: '0.18em', color: 'var(--text-secondary)', textTransform: 'uppercase', fontSize: 13 }}>TongJod</div>
        <div className="body thai" style={{ marginTop: 14, color: 'var(--text-secondary)' }}>
          {window.t('tagline', lang)}
        </div>
      </div>

      <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, display: 'flex', justifyContent: 'center', padding: '0 28px' }}>
        <button
          onClick={onSignIn}
          className="anim-card"
          style={{
            width: 290, maxWidth: '100%', cursor: 'pointer',
            background: '#fff', border: '1px solid var(--border)',
            borderRadius: 14, padding: '15px 20px',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12,
            boxShadow: '0 4px 18px rgba(28,25,23,0.12)',
            fontFamily: 'var(--body)', fontWeight: 600, fontSize: 15, color: 'var(--text-primary)',
            transition: 'transform 120ms ease-out',
          }}
          onMouseDown={(e) => (e.currentTarget.style.transform = 'scale(0.97)')}
          onMouseUp={(e) => (e.currentTarget.style.transform = 'none')}
          onMouseLeave={(e) => (e.currentTarget.style.transform = 'none')}
        >
          <GoogleG />
          <span className="thai" style={{ whiteSpace: 'nowrap' }}>{window.t('continueGoogle', lang)}</span>
        </button>
      </div>

      <div style={{ position: 'absolute', bottom: 32, left: 0, right: 0, textAlign: 'center' }}>
        <span className="caption" style={{ color: 'var(--text-muted)' }}>
          {lang === 'th' ? 'จดทุกบาท ก่อนจะลืม' : 'Note every baht before you forget'}
        </span>
      </div>
    </div>
  );
}

function GoogleG() {
  return (
    <svg width="20" height="20" viewBox="0 0 48 48">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.5 29.5 4.5 24 4.5 13.2 4.5 4.5 13.2 4.5 24S13.2 43.5 24 43.5 43.5 34.8 43.5 24c0-1.2-.1-2.3-.3-3.5z"/>
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12.5 24 12.5c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.5 29.5 4.5 24 4.5 16.3 4.5 9.7 8.9 6.3 14.7z"/>
      <path fill="#4CAF50" d="M24 43.5c5.4 0 10.3-2.1 14-5.4l-6.5-5.5c-2 1.5-4.6 2.4-7.5 2.4-5.2 0-9.6-3.3-11.2-8l-6.5 5C9.6 39 16.2 43.5 24 43.5z"/>
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.5 5.5C40.9 36.1 43.5 30.7 43.5 24c0-1.2-.1-2.3-.3-3.5z"/>
    </svg>
  );
}

window.Login = Login;
