/* TongJod — static config, sample data, i18n, helpers */

// ---------- Dynamic theme definitions ----------
const THEMES = {
  excellent: {
    key: 'excellent',
    gradient: 'linear-gradient(135deg, #D1FAE5 0%, #A7F3D0 40%, #6EE7B7 100%)',
    accent: '#059669',
    accentLight: '#34D399',
    cardTint: 'rgba(16, 185, 129, 0.08)',
    bar: '#10B981',
    pillBg: '#D1FAE5',
    pillText: '#065F46',
    focusRing: 'rgba(5, 150, 105, 0.15)',
  },
  onTrack: {
    key: 'onTrack',
    gradient: 'linear-gradient(135deg, #FEF9C3 0%, #FDE68A 40%, #FCD34D 100%)',
    accent: '#D97706',
    accentLight: '#FBBF24',
    cardTint: 'rgba(245, 158, 11, 0.08)',
    bar: '#F59E0B',
    pillBg: '#FEF3C7',
    pillText: '#92400E',
    focusRing: 'rgba(217, 119, 6, 0.15)',
  },
  over: {
    key: 'over',
    gradient: 'linear-gradient(135deg, #FFE4E6 0%, #FECDD3 40%, #FDA4AF 100%)',
    accent: '#DC2626',
    accentLight: '#FB7185',
    cardTint: 'rgba(239, 68, 68, 0.08)',
    bar: '#EF4444',
    pillBg: '#FFE4E6',
    pillText: '#9F1239',
    focusRing: 'rgba(220, 38, 38, 0.15)',
  },
  default: {
    key: 'default',
    gradient: 'linear-gradient(135deg, #F7F5F1 0%, #EDE9E3 100%)',
    accent: '#78716C',
    accentLight: '#A8A29E',
    cardTint: 'rgba(120, 113, 108, 0.06)',
    bar: '#A8A29E',
    pillBg: '#F0EDE8',
    pillText: '#57534E',
    focusRing: 'rgba(120, 113, 108, 0.15)',
  },
};

// ---------- Categories ----------
// usage_count drives chip ordering in the form
const EXPENSE_CATEGORIES = [
  { id: 'food', icon: 'Utensils', th: 'อาหาร', en: 'Food', usage: 48 },
  { id: 'transport', icon: 'Car', th: 'เดินทาง', en: 'Transport', usage: 31 },
  { id: 'shopping', icon: 'ShoppingBag', th: 'ช้อปปิ้ง', en: 'Shopping', usage: 22 },
  { id: 'bills', icon: 'ReceiptText', th: 'บิล/ค่าใช้จ่าย', en: 'Bills', usage: 14 },
  { id: 'health', icon: 'HeartPulse', th: 'สุขภาพ', en: 'Health', usage: 9 },
  { id: 'fun', icon: 'PartyPopper', th: 'บันเทิง', en: 'Fun', usage: 7 },
  { id: 'coffee', icon: 'Coffee', th: 'กาแฟ', en: 'Coffee', usage: 6 },
  { id: 'other_e', icon: 'Shapes', th: 'อื่นๆ', en: 'Other', usage: 3 },
];

const INCOME_CATEGORIES = [
  { id: 'salary', icon: 'Briefcase', th: 'เงินเดือน', en: 'Salary', usage: 12 },
  { id: 'freelance', icon: 'Laptop', th: 'ฟรีแลนซ์', en: 'Freelance', usage: 8 },
  { id: 'bonus', icon: 'Gift', th: 'โบนัส', en: 'Bonus', usage: 2 },
  { id: 'other_i', icon: 'Shapes', th: 'อื่นๆ', en: 'Other', usage: 1 },
];

function catById(id) {
  return [...EXPENSE_CATEGORIES, ...INCOME_CATEGORIES].find((c) => c.id === id);
}

// ---------- Budget ----------
const BUDGETS = {
  food: 8000,
  transport: 3500,
  shopping: 4500,
  bills: 5500,
  health: 1500,
  fun: 1000,
  coffee: 0,
  other_e: 0,
};

// ---------- Sample transactions (June 2026, days 1–9) ----------
// amount in baht. day = day of month.
const SAMPLE_TX = [
  { id: 't1', type: 'income', day: 1, cat: 'salary', amount: 32000, note: 'เงินเดือนมิถุนายน' },
  { id: 't2', type: 'expense', day: 1, cat: 'bills', amount: 4200, note: 'ค่าเช่าห้อง' },
  { id: 't3', type: 'expense', day: 1, cat: 'food', amount: 180, note: 'ข้าวเย็น' },
  { id: 't4', type: 'expense', day: 2, cat: 'food', amount: 240, note: '' },
  { id: 't5', type: 'expense', day: 2, cat: 'coffee', amount: 95, note: 'ลาเต้' },
  { id: 't6', type: 'expense', day: 2, cat: 'transport', amount: 120, note: 'BTS' },
  { id: 't7', type: 'expense', day: 3, cat: 'shopping', amount: 890, note: 'เสื้อยืด' },
  { id: 't8', type: 'expense', day: 3, cat: 'food', amount: 210, note: '' },
  { id: 't9', type: 'expense', day: 4, cat: 'food', amount: 350, note: 'นัดเพื่อน' },
  { id: 't10', type: 'expense', day: 4, cat: 'transport', amount: 80, note: '' },
  { id: 't11', type: 'income', day: 4, cat: 'freelance', amount: 5500, note: 'งานออกแบบโลโก้' },
  { id: 't12', type: 'expense', day: 5, cat: 'food', amount: 165, note: '' },
  { id: 't13', type: 'expense', day: 5, cat: 'fun', amount: 320, note: 'ดูหนัง' },
  { id: 't14', type: 'expense', day: 6, cat: 'food', amount: 420, note: 'บุฟเฟต์' },
  { id: 't15', type: 'expense', day: 6, cat: 'coffee', amount: 110, note: '' },
  { id: 't16', type: 'expense', day: 7, cat: 'health', amount: 650, note: 'ยา + วิตามิน' },
  { id: 't17', type: 'expense', day: 7, cat: 'food', amount: 190, note: '' },
  { id: 't18', type: 'expense', day: 8, cat: 'transport', amount: 220, note: 'แท็กซี่' },
  { id: 't19', type: 'expense', day: 8, cat: 'food', amount: 275, note: '' },
  { id: 't20', type: 'expense', day: 8, cat: 'shopping', amount: 540, note: 'ของใช้ในบ้าน' },
  { id: 't21', type: 'expense', day: 9, cat: 'food', amount: 230, note: 'ข้าวกลางวัน' },
  { id: 't22', type: 'expense', day: 9, cat: 'coffee', amount: 85, note: '' },
];

const MONTH = { th: 'มิถุนายน', en: 'June', year: 2026, daysInMonth: 30, today: 9 };

// ---------- i18n ----------
const STR = {
  tagline: { th: 'จดทุกบาท ใช้ชีวิตสบายใจ', en: 'Track every baht, live at ease' },
  continueGoogle: { th: 'เข้าสู่ระบบด้วย Google', en: 'Continue with Google' },
  baht: { th: 'บาท', en: 'THB' },
  income: { th: 'รายรับ', en: 'Income' },
  expense: { th: 'รายจ่าย', en: 'Expense' },
  avgPerDay: { th: 'เฉลี่ย {n} บาท/วัน', en: 'Avg {n} THB/day' },
  expected: { th: 'คาดการณ์ {n}%', en: 'Expected {n}%' },
  actual: { th: 'จริง {n}%', en: 'Actual {n}%' },
  dailyExpense: { th: 'รายจ่ายรายวัน', en: 'Daily spending' },
  topCategories: { th: 'หมวดหมู่ที่ใช้มากสุด', en: 'Top categories' },
  // nav
  navHome: { th: 'หน้าหลัก', en: 'Home' },
  navAdd: { th: 'เพิ่ม', en: 'Add' },
  navBudget: { th: 'งบประมาณ', en: 'Budget' },
  // status messages
  statusExcellent: { th: 'เยี่ยมมาก! คุมงบได้ดีสุดๆ 🌿', en: 'Excellent! You\u2019re well under budget 🌿' },
  statusOnTrack: { th: 'กำลังไปได้สวย ใช้จ่ายพอดีๆ', en: 'On track — spending right on pace' },
  statusOver: { th: 'ใช้เกินงบนิดหน่อยนะ ระวังหน่อย', en: 'A little over budget — ease up a bit' },
  statusDefault: { th: 'ยังไม่ได้ตั้งงบประมาณเดือนนี้', en: 'No budget set for this month' },
  // form
  formType: { th: 'วันนี้เป็น...', en: 'Today is a...' },
  formAmount: { th: 'จำนวนเท่าไหร่?', en: 'How much?' },
  formCategory: { th: 'หมวดหมู่ไหน?', en: 'Which category?' },
  formNote: { th: 'มีอะไรเพิ่มเติมไหม?', en: 'Anything to add?' },
  formDate: { th: 'วันที่?', en: 'Which date?' },
  formConfirm: { th: 'ตรวจสอบอีกครั้ง', en: 'Review once more' },
  continue: { th: 'ต่อไป', en: 'Continue' },
  skip: { th: 'ข้ามได้เลย', en: 'Skip' },
  today: { th: 'วันนี้', en: 'Today' },
  save: { th: 'บันทึก', en: 'Save' },
  edit: { th: 'แก้ไข', en: 'Edit' },
  editLast: { th: 'แก้ไขรายการล่าสุด', en: 'Edit last entry' },
  notePlaceholder: { th: 'เช่น ข้าวกลางวันกับเพื่อน', en: 'e.g. lunch with friends' },
  fType: { th: 'ประเภท', en: 'Type' },
  fAmount: { th: 'จำนวน', en: 'Amount' },
  fCategory: { th: 'หมวดหมู่', en: 'Category' },
  fNote: { th: 'โน้ต', en: 'Note' },
  fDate: { th: 'วันที่', en: 'Date' },
  noNote: { th: '—', en: '—' },
  saved: { th: 'บันทึกแล้ว!', en: 'Saved!' },
  // budget
  budgetTitle: { th: 'ตั้งงบประมาณ', en: 'Set budget' },
  totalBudget: { th: 'งบรวม', en: 'Total budget' },
  notSet: { th: 'ยังไม่ได้ตั้ง', en: 'Not set' },
  addCategory: { th: 'เพิ่มหมวดหมู่', en: 'Add category' },
  newCategory: { th: 'เพิ่มหมวดหมู่ใหม่', en: 'New category' },
  categoryName: { th: 'ชื่อหมวดหมู่', en: 'Category name' },
  monthlyBudgetNote: { th: 'งบรายจ่ายต่อเดือน', en: 'Monthly spending budget' },
};

function t(key, lang, vars) {
  const entry = STR[key];
  let s = entry ? entry[lang] : key;
  if (vars) Object.keys(vars).forEach((k) => { s = s.replace('{' + k + '}', vars[k]); });
  return s;
}

// ---------- Helpers ----------
function fmt(n) {
  return Math.round(n).toLocaleString('en-US');
}

function computeStatus(actualPct, expectedPct, hasBudget) {
  if (!hasBudget) return 'default';
  const diff = actualPct - expectedPct;
  if (diff <= -10) return 'excellent';
  if (diff <= 10) return 'onTrack';
  return 'over';
}

Object.assign(window, {
  THEMES, EXPENSE_CATEGORIES, INCOME_CATEGORIES, catById,
  BUDGETS, SAMPLE_TX, MONTH, STR, t, fmt, computeStatus,
});
