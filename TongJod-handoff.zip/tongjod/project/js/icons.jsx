/* Lucide icon renderer — reads icon node data from the lucide UMD global */
function Icon({ name, size = 22, strokeWidth = 2, color = 'currentColor', style, className }) {
  const lib = window.lucide || {};
  const node = (lib.icons && lib.icons[name]) || lib[name];
  if (!node || !node[2]) {
    return React.createElement('span', {
      style: { display: 'inline-block', width: size, height: size, ...style },
      className,
    });
  }
  const children = node[2].map((child, i) => {
    const [tag, attrs] = child;
    return React.createElement(tag, { key: i, ...attrs });
  });
  return React.createElement('svg', {
    xmlns: 'http://www.w3.org/2000/svg',
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: color,
    strokeWidth,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    style,
    className,
  }, children);
}

window.Icon = Icon;
